import React from 'react';
import ReactDOM from 'react-dom';
import App from './app';
import './global.css'; // If you have global styles
import './GlobalStyles.css';


ReactDOM.render(<App />, document.getElementById('root'));
