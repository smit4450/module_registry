export interface url_interface {
    bus_factor: number;
    bus_factor_latency:number;
    responsive_maintainer:number;
    responsive_maintainer_latency:number;
    ramp_up:number
    ramp_up_latency:number;
    correctness:number;
    correctness_latency :number;
    license:number
    license_latency:number
    depends: number;
    depends_latency:number;
    pull: number;
    pull_latency:number;
    net_score:number;
    net_score_latency:number,
    disk: number,
}
