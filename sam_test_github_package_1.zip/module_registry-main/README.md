ECE 461 Project Phase 1: Module Rating System

Phase 2 Group Members: Sam Johnson, Harrison Smith, Sydney Chang, Doha Hafez, Jana Gamal

Original Phase 1 Group Members: Ruth Sugiarto, Yingchen Jin, Varun Venkatesh, Ethan Hunt, Areej Mirani 

